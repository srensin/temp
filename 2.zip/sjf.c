#include <stdio.h>

int main()
{
    int n, i, time = 0, count = 0, smallest, last = -1;
    int at[10], bt[10], rt[10], wt[10], tat[10];
    int gantt_p[50], gantt_t[50], k = 0;
    float awt = 0, atat = 0;

    printf("Enter number of processes: ");
    scanf("%d", &n);

    for (i = 0; i < n; i++)
    {
        printf("AT P%d: ", i + 1);
        scanf("%d", &at[i]);

        printf("BT P%d: ", i + 1);
        scanf("%d", &bt[i]);

        rt[i] = bt[i];
        wt[i] = 0;
        tat[i] = 0;
    }

    gantt_t[k] = 0; // Start time 0

    while (count < n)
    {
        smallest = -1;

        for (i = 0; i < n; i++)
        {
            if (at[i] <= time && rt[i] > 0)
            {
                if (smallest == -1 || rt[i] < rt[smallest])
                    smallest = i;
            }
        }

        if (smallest == -1)
        {
            time++;
            continue;
        }

        // When process switches
        if (last != smallest)
        {
            gantt_p[k] = smallest;
            gantt_t[k] = time;
            k++;
            last = smallest;
        }

        rt[smallest]--;
        time++;

        // Process finished
        if (rt[smallest] == 0)
        {
            count++;
            tat[smallest] = time - at[smallest];
            wt[smallest] = tat[smallest] - bt[smallest];
            awt += wt[smallest];
            atat += tat[smallest];
        }
    }

    gantt_t[k] = time; // End time

    // Print Gantt Chart
    printf("\nGantt Chart:\n|");
    for (i = 0; i < k; i++)
        printf(" P%d |", gantt_p[i] + 1);

    printf("\n");
    for (i = 0; i <= k; i++)
        printf("%-5d", gantt_t[i]);

    // Print WT and TAT per process
    printf("\n\nProcess\tAT\tBT\tWT\tTAT\n");
    for (i = 0; i < n; i++)
        printf("P%d\t%d\t%d\t%d\t%d\n", i + 1, at[i], bt[i], wt[i], tat[i]);

    printf("\nAverage WT = %.2f", awt / n);
    printf("\nAverage TAT = %.2f\n", atat / n);

    return 0;
}

#include<stdio.h>

int main() {
    int n, i, min_idx, current_time = 0, completed = 0;
    int burst[20], arrival[20], completion[20], waiting[20], turnaround[20];
    int is_completed[20] = {0};
    int gantt_p[20], gantt_t[21], k = 0;

    float total_wt = 0, total_tat = 0;

    printf("Enter number of processes: ");
    scanf("%d", &n);

    printf("Enter burst time and arrival time for each process:\n");
    for(i = 1; i <= n; i++) {
        printf("P%d: ", i);
        scanf("%d %d", &burst[i], &arrival[i]);
    }

    gantt_t[0] = 0;

    while(completed != n) {
        min_idx = -1;
        int min_burst = 9999;

        for(i = 1; i <= n; i++) {
            if(arrival[i] <= current_time && is_completed[i] == 0) {
                if(burst[i] < min_burst) {
                    min_burst = burst[i];
                    min_idx = i;
                }
            }
        }

        if(min_idx != -1) {

            gantt_p[k] = min_idx;   // store process for gantt

            completion[min_idx] = current_time + burst[min_idx];
            turnaround[min_idx] = completion[min_idx] - arrival[min_idx];
            waiting[min_idx] = turnaround[min_idx] - burst[min_idx];

            total_wt += waiting[min_idx];
            total_tat += turnaround[min_idx];

            current_time = completion[min_idx];
            gantt_t[k+1] = current_time;

            is_completed[min_idx] = 1;
            completed++;
            k++;
        }
        else {
            current_time++; 
        }
    }

    printf("\nGantt Chart:\n");

    for(i = 0; i < k; i++)
        printf("| P%d ", gantt_p[i]);
    printf("|\n");

    for(i = 0; i <= k; i++)
        printf("%d   ", gantt_t[i]);

    printf("\n");

    printf("\nProcess\tArrival\tBurst\tWaiting\tCompletion\tTurnaround\n");
    for(i = 1; i <= n; i++)
        printf("P%d\t%d\t%d\t%d\t%d\t\t%d\n",
        i, arrival[i], burst[i], waiting[i], completion[i], turnaround[i]);

    printf("\nAverage waiting time = %.2f", total_wt/n);
    printf("\nAverage turnaround time = %.2f\n", total_tat/n);

    return 0;
}
#include <stdio.h>

int main() {
    int n, i;
    int bt[20], at[20], ct[20], wt[20], tat[20];
    float avg_wt = 0, avg_tat = 0;

    printf("Enter number of processes: ");
    scanf("%d", &n);

    printf("Enter Arrival Time and Burst Time for each process:\n");
    for (i = 0; i < n; i++) {
        printf("P%d: ", i + 1);
        scanf("%d %d", &at[i], &bt[i]);
    }

    // Calculating Completion Time (CT)
    for (i = 0; i < n; i++) {
        if (i == 0) {
            ct[i] = at[i] + bt[i];
        } else {
            // If process arrives after the previous one finishes
            if (at[i] > ct[i - 1]) {
                ct[i] = at[i] + bt[i];
            } else {
                ct[i] = ct[i - 1] + bt[i];
            }
        }
        
        // TAT = Completion Time - Arrival Time
        tat[i] = ct[i] - at[i];
        // WT = Turnaround Time - Burst Time
        wt[i] = tat[i] - bt[i];

        avg_wt += wt[i];
        avg_tat += tat[i];
    }

    // Display Table
    printf("\nProcess\tAT\tBT\tCT\tTAT\tWT\n");
    for (i = 0; i < n; i++) {
        printf("P%d\t%d\t%d\t%d\t%d\t%d\n", i + 1, at[i], bt[i], ct[i], tat[i], wt[i]);
    }

    printf("\nAverage Turnaround Time = %.2f", avg_tat / n);
    printf("\nAverage Waiting Time = %.2f\n", avg_wt / n);

    // Simple Gantt Chart
    printf("\nGantt Chart:\n ");
    for(i = 0; i < n; i++) printf("------- ");
    printf("\n|");
    for(i = 0; i < n; i++) printf("  P%d  |", i + 1);
    printf("\n ");
    for(i = 0; i < n; i++) printf("------- ");
    printf("\n0");
    for(i = 0; i < n; i++) printf("      %d", ct[i]);
    printf("\n");

    return 0;
}
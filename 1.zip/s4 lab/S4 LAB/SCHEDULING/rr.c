#include<stdio.h>

int main() {
    int n,i,qt,current_time=0,completed=0;
    int burst[20],arrival[20],rt[20],completion[20],waiting[20],turnaround[20];
    int gantt_p[100], gantt_t[100], k=0;
    float total_wt=0,total_tat=0;

    printf("Enter number of processes: ");
    scanf("%d",&n);

    printf("Enter Time Quantum: ");
    scanf("%d",&qt);

    for(i=1;i<=n;i++){
        printf("P%d burst and arrival: ",i);
        scanf("%d %d",&burst[i],&arrival[i]);
        rt[i]=burst[i];
    }

    gantt_t[k]=0;

    while(completed<n){
        int flag=0;

        for(i=1;i<=n;i++){
            if(arrival[i]<=current_time && rt[i]>0){
                flag=1;

                gantt_p[k]=i;

                if(rt[i]>qt){
                    current_time+=qt;
                    rt[i]-=qt;
                }
                else{
                    current_time+=rt[i];
                    rt[i]=0;
                    completed++;

                    completion[i]=current_time;
                    turnaround[i]=completion[i]-arrival[i];
                    waiting[i]=turnaround[i]-burst[i];

                    total_wt+=waiting[i];
                    total_tat+=turnaround[i];
                }

                k++;
                gantt_t[k]=current_time;
            }
        }

        if(flag==0)
            current_time++;
    }

    printf("\nGantt Chart:\n");

    for(i=0;i<k;i++)
        printf("| P%d ",gantt_p[i]);

    printf("|\n");

    for(i=0;i<=k;i++)
        printf("%d   ",gantt_t[i]);

    printf("\n");

    printf("\nProcess\tAT\tBT\tWT\tCT\tTAT\n");
    for(i=1;i<=n;i++)
        printf("P%d\t%d\t%d\t%d\t%d\t%d\n",i,arrival[i],burst[i],waiting[i],completion[i],turnaround[i]);

    printf("\nAverage WT = %.2f",total_wt/n);
    printf("\nAverage TAT = %.2f\n",total_tat/n);

    return 0;
}
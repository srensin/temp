#include<stdio.h>

int main() {
    int n, i, current_time = 0, completed = 0, min_idx;
    int burst[20], arrival[20], rt[20], completion[20], waiting[20], turnaround[20];
    int gantt_p[200], gantt_t[200], k = 0;
    float total_wt = 0, total_tat = 0;

    printf("Enter number of processes: ");
    scanf("%d", &n);

    for(i = 1; i <= n; i++) {
        printf("P%d burst and arrival: ", i);
        scanf("%d %d", &burst[i], &arrival[i]);
        rt[i] = burst[i];
    }

    gantt_t[0] = 0;

    while(completed != n) {
        min_idx = -1;
        int min_rt = 9999;

        for(i = 1; i <= n; i++) {
            if(arrival[i] <= current_time && rt[i] > 0) {
                if(rt[i] < min_rt) {
                    min_rt = rt[i];
                    min_idx = i;
                }
            }
        }

        if(min_idx != -1) {

            gantt_p[k] = min_idx;   // store process in gantt chart

            rt[min_idx]--;

            if(rt[min_idx] == 0) {
                completed++;
                completion[min_idx] = current_time + 1;
                turnaround[min_idx] = completion[min_idx] - arrival[min_idx];
                waiting[min_idx] = turnaround[min_idx] - burst[min_idx];

                total_wt += waiting[min_idx];
                total_tat += turnaround[min_idx];
            }

            current_time++;
            k++;
            gantt_t[k] = current_time;
        }
        else {
            current_time++;
        }
    }

    printf("\nGantt Chart:\n");

    for(i = 0; i < k; i++)
        printf("| P%d ", gantt_p[i]);
    printf("|\n");

    for(i = 0; i <= k; i++)
        printf("%d   ", gantt_t[i]);

    printf("\n");

    printf("\nProcess\tArrival\tBurst\tWaiting\tCompletion\tTurnaround\n");
    for(i = 1; i <= n; i++)
        printf("P%d\t%d\t%d\t%d\t%d\t\t%d\n",
        i, arrival[i], burst[i], waiting[i], completion[i], turnaround[i]);

    printf("\nAverage waiting time = %.2f\n", total_wt/n);
    printf("Average turnaround time = %.2f\n", total_tat/n);

    return 0;
}
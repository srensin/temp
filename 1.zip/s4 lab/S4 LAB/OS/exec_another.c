#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main()
{
    pid_t pid = fork();

    if(pid == 0)
    {
        printf("Child process executing...\n");
        execl("/bin/date","date",NULL);
    }
    else
    {
        wait(NULL);
        printf("Parent process finished\n");
    }

    return 0;
}
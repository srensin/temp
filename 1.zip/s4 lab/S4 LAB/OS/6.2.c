#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char *argv[]) 
{
    int fd1;
    
    // Opens the file specified in the first command-line argument in read-only mode
    fd1 = open(argv[1], O_RDONLY);
    
    if (fd1 < 0) 
    {
        perror("Error opening source file");
        exit(EXIT_FAILURE);
    } 
    else 
    {
        printf("File exists");
    }

    return 0;
}
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define BUF_SIZE 4096

int main(int argc, char *argv[]) {

    if (argc != 3) {
        fprintf(stderr, "Usage: %s source destination\n", argv[0]);
        exit(1);
    }

    int src = open(argv[1], O_RDONLY);
    if (src < 0) {
        perror("open source");
        exit(1);
    }

    int dest = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (dest < 0) {
        perror("open destination");
        close(src);
        exit(1);
    }

    char buf[BUF_SIZE];
    ssize_t n;

    while ((n = read(src, buf, BUF_SIZE)) > 0) {

        for (ssize_t i = 0; i < n; i++) {

            if (buf[i] != ' ' && buf[i] != '\0') {  
                write(dest, &buf[i], 1);   // write only valid characters
            }

        }

        memset(buf, 0, BUF_SIZE); // clear buffer to avoid leftover bytes
    }

    if (n < 0) {
        perror("read");
        exit(1);
    }

    close(src);
    close(dest);

    printf("File copied successfully without spaces or NULL characters.\n");

    return 0;
}
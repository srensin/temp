#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main()
{
    pid_t pid;

    pid = fork();

    if(pid == 0)
    {
        // Child process
        printf("Child process started\n");
        sleep(5);   // pause execution for 5 seconds
        printf("Child process finished\n");
    }
    else if(pid > 0)
    {
        // Parent process
        wait(NULL);   // wait for child to finish
        printf("Parent process resumes after child completion\n");
    }
    else
    {
        printf("Fork failed\n");
    }

    return 0;
}
#include <sys/stat.h>
#include <stdio.h>
#include <time.h>

int main() {
    struct stat s;

    /* Check if stat succeeds */
    if (stat("file.txt", &s) == -1) {
        perror("stat failed");
        return 1;
    }

    printf("File Size: %ld bytes\n", (long)s.st_size);

    printf("Last Modified: %s", ctime(&s.st_mtime));

    printf("Permissions: %o\n", s.st_mode & 0777);

    if (S_ISREG(s.st_mode))
        printf("Regular File\n");
    else if (S_ISDIR(s.st_mode))
        printf("Directory\n");
    else
        printf("Other File Type\n");

    return 0;
}
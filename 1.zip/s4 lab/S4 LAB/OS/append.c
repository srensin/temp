#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    int src, dest;
    char buffer[1024];
    int n;

    src = open("file1.txt", O_RDONLY);
    dest = open("file2.txt", O_WRONLY | O_APPEND);

    while((n = read(src, buffer, sizeof(buffer))) > 0)
    {
        write(dest, buffer, n);
    }

    close(src);
    close(dest);

    printf("File appended successfully\n");

    return 0;
}
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <string.h>

int main(int argc,char**argv){if(argc!=3){perror("src dest");return 1;}
int s=open(argv[1],O_RDONLY),d=open(argv[2],O_WRONLY|O_CREAT|O_TRUNC,0644);
if(s<0||d<0){perror("open");return 1;}
char b[4096];int n=1;ssize_t r;
while((r=read(s,b,sizeof b))>0){
  for(char*p=b,*e=b+r;p<e;){
    char*nl=memchr(p,'\n',e-p);
    if(!nl)nl=e;
    if(n%2==0) {
      
      ssize_t len = nl - p;
      write(d, p, len);
      if(nl < e) write(d, "\n", 1);
    }
    if(nl<e){n++;p=nl+1;}
    else break;
  }}
close(s);
close(d);
return 0;}

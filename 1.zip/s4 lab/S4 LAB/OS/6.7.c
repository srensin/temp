#include <fcntl.h>
#include <unistd.h>
#include <ctype.h>

int main(int c, char *v[]) {
    int s = open(v[1], O_RDONLY);
    int d = open(v[2], O_WRONLY|O_CREAT|O_TRUNC, 0644);
    char b[4096];
    ssize_t n;

    while ((n = read(s, b, sizeof b)) > 0) {
        for (int i = 0; i < n; i++)
            b[i] = toupper((unsigned char)b[i]);
        write(d, b, n);
    }

    close(s);
    close(d);
    return 0;
}
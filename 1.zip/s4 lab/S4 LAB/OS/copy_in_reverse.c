#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    int src, dest;
    char ch;
    off_t size;

    src = open("source.txt", O_RDONLY);
    dest = open("reverse.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);

    size = lseek(src, 0, SEEK_END);

    for(int i = size - 1; i >= 0; i--)
    {
        lseek(src, i, SEEK_SET);
        read(src, &ch, 1);
        write(dest, &ch, 1);
    }

    close(src);
    close(dest);

    printf("Reverse copy completed\n");

    return 0;
}
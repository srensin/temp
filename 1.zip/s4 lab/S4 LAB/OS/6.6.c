#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

#define BUF_SIZE 4096

int main(int argc, char *argv[]) {

    if (argc != 3) {
        fprintf(stderr, "Usage: %s file1 file2\n", argv[0]);
        exit(1);
    }

    int fd1 = open(argv[1], O_RDONLY);
    int fd2 = open(argv[2], O_RDONLY);

    if (fd1 < 0 || fd2 < 0) {
        perror("open");
        exit(1);
    }

    char buf1[BUF_SIZE], buf2[BUF_SIZE];
    ssize_t r1, r2;
    int identical = 1;

    while (1) {
        r1 = read(fd1, buf1, BUF_SIZE);
        r2 = read(fd2, buf2, BUF_SIZE);

        if (r1 < 0 || r2 < 0) {
            perror("read");
            exit(1);
        }

        if (r1 != r2) {
            identical = 0;
            break;
        }

        if (r1 == 0)   // End of both files
            break;

        for (int i = 0; i < r1; i++) {
            if (buf1[i] != buf2[i]) {
                identical = 0;
                break;
            }
        }

        if (!identical)
            break;
    }

    if (identical)
        printf("Files are identical\n");
    else
        printf("Files are not identical\n");

    close(fd1);
    close(fd2);

    return 0;
}
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>

#define BUF_SIZE 4096

void copy(int src, int dest) {
    char buf[BUF_SIZE];
    char out[BUF_SIZE];
    ssize_t r;

    while ((r = read(src, buf, BUF_SIZE)) > 0) {

        int j = 0;

        for (int i = 0; i < r; i++) {
            if (buf[i] != '\0') {   // remove NULL characters
                out[j++] = buf[i];
            }
        }

        if (j > 0)
            write(dest, out, j);   // write only valid bytes
    }

    if (r < 0) {
        perror("read error");
        exit(1);
    }
}

int main(int argc, char *argv[]) {

    if (argc != 4) {
        printf("Usage: %s file1 file2 destination\n", argv[0]);
        exit(1);
    }

    int fd1 = open(argv[1], O_RDONLY);
    if (fd1 < 0) {
        perror("Error opening file1");
        exit(1);
    }

    int fd2 = open(argv[2], O_RDONLY);
    if (fd2 < 0) {
        perror("Error opening file2");
        close(fd1);
        exit(1);
    }

    int fd3 = open(argv[3], O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd3 < 0) {
        perror("Error creating destination file");
        close(fd1);
        close(fd2);
        exit(1);
    }

    copy(fd1, fd3);
    copy(fd2, fd3);

    close(fd1);
    close(fd2);
    close(fd3);

    printf("Files copied successfully.\n");

    return 0;
}